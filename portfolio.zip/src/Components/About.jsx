import React from 'react'

const About = () => {
    return (
        <>
            <section className='about-sec'>
                <div className='container'>
                    <div className='row align-items-top'>
                        <div className='col-md-6'>

                            <img src="https://newtemplate.net/demo/resume/template/default/images/about-image.png" alt="" />

                        </div>
                        <div className='col-md-6'>
                            <div className=''>
                                <h3>About Me</h3>
                                <h5>I am a Full-Stack Web Developer</h5>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente inventore provident, voluptates modi esse natus, quis voluptatum error dolores repudiandae quibusdam eius repellendus vel ipsa facere consequuntur eos nihil omnis.</p>
                                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure libero officiis maiores reprehenderit aperiam laudantium! Exercitationem, beatae. Ex aspernatur explicabo quam vero consequuntur laborum dolorum, totam illo iste modi cupiditate?</p>
                                <hr />
                                <ul class="list-inline about-info">
                                    <li> <span>Name:</span> <p>Sadiq Siddiqui</p> </li>
                                    <li> <span>Email:</span> <p><a href="mailto:sadiq@example.com">sadiq@example.com</a></p> </li>
                                    <li> <span>Number:</span> <p>25</p> </li>
                                    <li> <span>From:</span> <p>Noida, India</p> </li> </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
}

export default About