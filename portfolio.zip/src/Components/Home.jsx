import React from 'react'

const Home = () => {
    return (
        <>
            <div className='home-area'>
                <div className='container h-100' style={{ marginTop: '200px' }}>
                    <div className='row h-100'>
                        <div className='col-12 col-md-6 home-content'>
                            <h5>Hello, my name is <strong>Abul Kaish</strong></h5>
                            <h1>I'm a Developer</h1>
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloribus neque ad minima debitis, dolore ratione. Labore nostrum eveniet in modi expedita recusandae, cumque incidunt eaque facilis, nisi necessitatibus eum minus...</p>
                            <div style={{display:'flex', gap:'30px'}}>
                            <button className='banner-btn'> About me</button> <button className=' banner-btn btn-color'> Portfolio</button>
                            </div>
                        </div>
                    </div>
                    <div class="image-item row h-100 align-items-center"> <img src="https://newtemplate.net/demo/resume/template/default/images/big-profile.png" alt=""/> </div>
                </div>
            </div>


        </>
    )
}

export default Home